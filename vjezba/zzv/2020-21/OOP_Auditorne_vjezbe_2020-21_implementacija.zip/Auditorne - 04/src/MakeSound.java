public interface MakeSound {
    public void makeSound();
}
