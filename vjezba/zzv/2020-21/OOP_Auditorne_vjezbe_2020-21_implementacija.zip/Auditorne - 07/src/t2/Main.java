package t2;

public class Main {
    public static void main(String[] args) {
        MySortedList<String> list = new MySortedList<>();
        list.add("E");
        list.add("D");
        list.add("B");
        list.add("A");
        list.add("F");
        // list.add(0);
        list.print();
        System.out.println("---");



    }
}
