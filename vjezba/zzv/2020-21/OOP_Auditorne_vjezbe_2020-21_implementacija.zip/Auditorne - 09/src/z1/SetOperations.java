package z1;

import java.util.*;

class SetOperations {
    public static void main(String[] args) {
        var set1 = Set.of(1, 2, 3, 4, 5);
        var set2 = Set.of(3, 4, 5, 6, 7);

        System.out.println("Union: " + Union(set1, set2));

        System.out.println();

        System.out.println("IntersectForLoop: " + IntersectForLoop(set1, set2));
        System.out.println("IntersectRetainAll: " + IntersectRetainAll(set1, set2));

        System.out.println();

        System.out.println("DifferenceCode: " + DifferenceCode(set1, set2));
        System.out.println("DifferenceMethods: " + DifferenceMethods(set1, set2));
    }

    public static <T> Set<T> Union(Set<T> set1, Set<T> set2){
        Set<T> union = new HashSet<>(set1);
        union.addAll(set2);

        return union;
    }

    public static <T> Set<T> IntersectForLoop(Set<T> set1, Set<T> set2){
        Set<T> intersect = new HashSet<>();
        for (T element1 : set1){
            for (T element2 : set2){
                if (element1 == element2){
                    intersect.add(element1);
                    break;
                }
            }
        }

        return intersect;
    }

    public static <T> Set<T> IntersectRetainAll(Set<T> set1, Set<T> set2){
        Set<T> intersect = new HashSet<>(set1);
        intersect.retainAll(set2);

        return intersect;
    }

    public static <T> Set<T> DifferenceCode(Set<T> set1, Set<T> set2){
        Set<T> intersect = new HashSet<>(set1);
        intersect.retainAll(set2);

        Set<T> union = new HashSet<>(set1);
        union.addAll(set2);
        union.removeAll(intersect);

        return union;
    }

    public static <T> Set<T> DifferenceMethods(Set<T> set1, Set<T> set2){
        Set<T> difference = new HashSet<>(Union(set1, set2));
        difference.removeAll(IntersectRetainAll(set1, set2));

        return difference;
    }
}
