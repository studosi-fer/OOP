package hr.fer.oop.primjeri.p005;

public interface Instruction {
	public void execute(Registers registers,Memory memory);
}
