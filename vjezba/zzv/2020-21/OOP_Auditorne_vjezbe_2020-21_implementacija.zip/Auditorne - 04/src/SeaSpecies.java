public enum SeaSpecies {
    FISH, CEPHALOPOD, CRUSTACEAN
}
