package t3;

public abstract class Container <T extends Toy> {
    private final int capacity;
    private MyList<T> list = new MyList<>();

    public Container(int capacity) {
        this.capacity = capacity;
    }

    public void addToy(T toy) throws TooLittleSpace{
        if (capacity < toy.getVolume() + getTotalOccupance()){
            throw new TooLittleSpace("Container exceedes capacity by " + (toy.getVolume() + getTotalOccupance() - capacity));

        } else {
            list.add(toy);

        }

    }

    public T getToy(int index){
        return list.elementAt(index);
    }

    public int getNumOfToys(){
        return list.size();
    }

    public int getTotalOccupance(){
        int total = 0;
        for (int i = 0; i < getNumOfToys(); i++) {
            total += getToy(i).getVolume(); // list.elementAt(i).getVolume();
        }
        return total;
    }

    @Override
    public String toString() {
        return (getContainerType() + " of capacity: " + this.capacity + ", total occupance: " + getTotalOccupance());
    }

    protected abstract String getContainerType();
}
