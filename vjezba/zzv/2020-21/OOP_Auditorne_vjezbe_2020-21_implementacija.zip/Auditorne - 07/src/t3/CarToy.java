package t3;

public class CarToy extends Toy{
    public CarToy(int volume, String name) {
        super(volume, name);
    }

    @Override
    public String toString(){
        return String.format("Car: %s", super.toString());
    }
}
