package z2.list;

import java.util.LinkedList;
import java.util.List;

class JavelinScores {
    private List<Score> scoreList;

    public JavelinScores() {
        this.scoreList = new LinkedList<>();
    }

    public void add(String name, double distance){
        Score score = new Score(name, distance);

        int i;
        for (i = 0; i < scoreList.size(); i++) {
            if (distance > scoreList.get(i).getDistance()){
                break;
            }
        }

        scoreList.add(i, score);
    }

    public void print(){
        for (Score score : scoreList) {
            System.out.println(score);
        }
    }

    @Override
    public String toString() {
        return String.valueOf(scoreList);
    }
}
