package t1;

public class Prodavac {

    private String zapis;

    public Prodavac(String zapis) {
        this.zapis = zapis;
    }

    public static void zabiljezi(String zapis) {

        try {
            String[] vrijednosti = zapis.split(",");

            double ukupnaCijena = Double.parseDouble(vrijednosti[0]);
            int brojProizvoda = Integer.parseInt(vrijednosti[1]);
            double vraceniIznos = Double.parseDouble(vrijednosti[2]);

            if (ukupnaCijena <= 0 || brojProizvoda < 1 || vraceniIznos < 0){
                throw new IllegalArgumentException("Nemoguć zapis");
            }

            double cijenaProizvoda = (ukupnaCijena - vraceniIznos) / brojProizvoda;

            System.out.println("Jedinična cijena: " + cijenaProizvoda);

        } catch (NullPointerException | ArrayIndexOutOfBoundsException | IllegalArgumentException e) {
            System.err.println("ERROR 404: " + e.getMessage());
        } catch (Exception e){
            System.err.println("Unknown error: " + e.getMessage());
        }

    }
}