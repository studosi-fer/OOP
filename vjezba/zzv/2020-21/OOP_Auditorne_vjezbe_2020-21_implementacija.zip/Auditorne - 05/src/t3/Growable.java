package t3;

public interface Growable {
    void fertilize();
    void water(int amount);
}
