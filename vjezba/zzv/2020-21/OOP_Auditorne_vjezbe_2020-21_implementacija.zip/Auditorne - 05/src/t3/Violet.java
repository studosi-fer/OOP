package t3;

public class Violet extends Plant{

    public Violet (int waterNeeded){
        super.waterNeeded = waterNeeded;
    }

}
