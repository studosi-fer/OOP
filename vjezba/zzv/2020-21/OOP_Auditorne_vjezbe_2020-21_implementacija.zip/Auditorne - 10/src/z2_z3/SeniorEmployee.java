package z2_z3;

import java.util.function.Predicate;

public class SeniorEmployee implements Predicate<Employee> {
    @Override
    public boolean test(Employee employee){
        return employee.getSalary() >= 80000;
    }
}
