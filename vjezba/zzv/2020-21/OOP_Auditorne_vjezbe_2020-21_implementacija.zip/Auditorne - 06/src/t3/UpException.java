package t3;

public class UpException extends RuntimeException{

    private static final long serialVersionUID = 1L;

    public UpException(String message){
        super(message);
    }
}
