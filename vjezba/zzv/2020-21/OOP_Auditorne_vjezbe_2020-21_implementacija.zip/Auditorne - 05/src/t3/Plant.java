package t3;

public class Plant implements Growable{

    public static final String GARDENER = "Tom";

    protected int waterNeeded;
    private int collectedWater;
    private boolean fertilized;

    public void water(int amount){
        this.collectedWater += amount;
        if (this instanceof Tomato){
            System.out.println("Using the sprinkler to water the tomato...");
        }else if (this instanceof Violet){
            System.out.println("Watering the violet with a watering can...");
        }
    }

    public void fertilize(){
        this.fertilized = true;
        System.out.println("This plant has been fertilized.");
    }

    public boolean pluck(){
        if (fertilized == true && collectedWater == waterNeeded){
            fertilized = false;
            collectedWater = 0;
            System.out.println("The plant has been plucked!");
            return true;
        }

        System.out.println("This plant is not ready to be plucked.");
        return false;
    }
}
