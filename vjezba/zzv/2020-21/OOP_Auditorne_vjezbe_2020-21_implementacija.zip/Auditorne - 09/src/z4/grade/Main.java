package z4.grade;

public class Main {
    public static void main(String[] args) {
        Grades math = new Grades();

        math.addStudentGrade("Ivo", 3);
        math.addStudentGrade("Jale", 4);
        math.addStudentGrade("Pivo", 4);
        math.addStudentGrade("Mare", 5);
        math.addStudentGrade("Božo", 1);

        math.printAverage();
    }
}
