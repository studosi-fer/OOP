package z1;

import java.util.Map;

public class Main {
    public static void main(String[] args) {
        Map<String, Map<String, Integer>> gradeMaps = Loader.loadData();

        System.out.println("Average grade: " + getAverageGrade(gradeMaps));

        increaseGrades(gradeMaps, "arts");
        System.out.println("Average grade: " + getAverageGrade(gradeMaps));


    }

    private static void increaseGrades(Map<String, Map<String, Integer>> gradeMaps, String course) {
        for (String name: gradeMaps.get(course).keySet())
            gradeMaps.get(course).compute(name, (key, value) -> value < 5 ? value + 1 : value);
    }

    private static double getAverageGrade(Map<String, Map<String, Integer>> gradeMaps) {
        return gradeMaps.values().stream().flatMap(nameGradeMap -> nameGradeMap.values().stream())
                .mapToInt(Integer::intValue).average().getAsDouble();
    }
}