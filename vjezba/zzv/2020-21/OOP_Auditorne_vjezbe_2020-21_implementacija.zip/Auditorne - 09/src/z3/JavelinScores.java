package z3;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

class JavelinScores {
    private Set<Score> scoreList;

    public JavelinScores() {
        this.scoreList = new TreeSet<>();
    }

    public void add(String name, double distance){
        scoreList.add(new Score(name, distance));
    }

    public void print(){
        for (Score score : scoreList) {
            System.out.println(score);
        }
    }

    public void printBest(){
        Set<String> outputNames = new HashSet<>();

        for (Score score : scoreList) {

//            if (!outputNames.contains(score.getName())){
//                System.out.println(score);
//                outputNames.add(score.getName());
//            }

            if (outputNames.add(score.getName()))
                System.out.println(score);
        }
    }

    @Override
    public String toString() {
        return String.valueOf(scoreList);
    }
}
