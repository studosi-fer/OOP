package z4.passed;

public class Main {
    public static void main(String[] args) {
        Grades g = new Grades();

        g.add("Ivo", "Math", 4);
        g.add("Ivo", "PE", 3);
        g.add("Ivo", "English", 4);
        g.add("Jale", "Math", 3);
        g.add("Jale", "PE", 5);
        g.add("Božo", "Math", 2);

        g.printAverageSubjectGrade("Math");
        g.printAverageSubjectGrade("PE");
        g.printAverageSubjectGrade("English");
    }
}
