package z2.set;

import java.util.Set;
import java.util.TreeSet;

class JavelinScores {
    private Set<Score> scoreList;

    public JavelinScores() {
        this.scoreList = new TreeSet<>();
    }

    public void add(String name, double distance){
        scoreList.add(new Score(name, distance));
    }

    public void print(){
        for (Score score : scoreList) {
            System.out.println(score);
        }
    }

    @Override
    public String toString() {
        return String.valueOf(scoreList);
    }
}
