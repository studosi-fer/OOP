public class Animal {

    public void introduceYourself(){
        System.out.println("I am an animal!");
    }
}
