package z2.set;

public class Main {
    public static void main(String[] args) {
        JavelinScores scores = new JavelinScores();
        scores.add("Sara", 68.43);
        scores.add("Sara", 66.18);
        scores.add("Steffi", 68.34);
        scores.add("Bruno", 69.69);

        System.out.println(scores);
        System.out.println();
        scores.print();
    }
}
