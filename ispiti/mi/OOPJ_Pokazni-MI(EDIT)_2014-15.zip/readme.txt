Za pokretanje programa samo promijenite "main1" u "main" i sve ostale u "main1" 
ili neko drugo ime.