public abstract class SeaAnimal extends Animal{

    private SeaSpecies species;

    public SeaAnimal(SeaSpecies species){
        this.species = species;
    }

    public abstract void wayOfMovement();

    @Override
    public final void introduceYourself(){
        System.out.println("I am a sea animal.");
    }

}
