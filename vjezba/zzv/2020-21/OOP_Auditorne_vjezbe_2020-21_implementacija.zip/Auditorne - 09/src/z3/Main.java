package z3;

public class Main {
    public static void main(String[] args) {
        JavelinScores scores = new JavelinScores();
        scores.add("Sara", 68.43);
        scores.add("Sara", 66.18);
        scores.add("Steffi", 68.34);
        scores.add("Bruno", 69.69);

        scores.print();
        System.out.println();
        scores.printBest();
    }
}
