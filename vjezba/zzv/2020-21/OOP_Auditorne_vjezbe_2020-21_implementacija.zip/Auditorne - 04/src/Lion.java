public class Lion extends Animal implements MakeSound{

    @Override
    public void makeSound() {
        System.out.println("Lion: \"Roar\"");
    }

    @Override
    public void introduceYourself(){
        System.out.println("I am a lion");
    }
}
