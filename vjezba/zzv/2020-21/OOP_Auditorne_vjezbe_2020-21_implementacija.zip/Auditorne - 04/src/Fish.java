public class Fish extends SeaAnimal{

    public Fish() {
        super(SeaSpecies.FISH);
    }

    public void wayOfMovement(){
        System.out.println("A fishy moves by swimming and walking");
    }


}
