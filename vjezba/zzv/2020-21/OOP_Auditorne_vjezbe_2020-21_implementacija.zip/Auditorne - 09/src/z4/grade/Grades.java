package z4.grade;

import java.util.HashMap;
import java.util.Map;

class Grades {
    private Map<String, Integer> subjectGrades;

    public Grades() {
        this.subjectGrades = new HashMap<>();
    }

    public void addStudentGrade(String name, int grade){
         subjectGrades.put(name, grade);
    }

    public void printAverage(){
        Integer sum = 0;

        for (Integer grade : subjectGrades.values()){
            sum += grade;
        }

        System.out.println("Average grade: " + sum.doubleValue() / subjectGrades.size());
    }
}
