package z4.grades;

public class Main {
    public static void main(String[] args) {
        Grades math = new Grades();

        math.addStudentGrade("Ivo", 3, 4);
        math.addStudentGrade("Jale", 4, 3, 5);
        math.addStudentGrade("Božo", 1, 2);

        System.out.println("Ivo: " + math.getStudentAverage("Ivo") + "\n");
        math.printAverageGrades();
    }
}
