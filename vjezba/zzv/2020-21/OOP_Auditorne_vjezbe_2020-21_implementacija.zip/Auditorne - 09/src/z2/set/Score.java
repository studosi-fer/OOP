package z2.set;

class Score implements Comparable<Score>{
    private String name;
    private double distance;

    public Score(String name, double distance) {
        this.name = name;
        this.distance = distance;
    }

    @Override
    public String toString() {
        return "name= " + name + ", distance= " + distance + "m";
    }

    @Override
    public int compareTo(Score obj) {

//        if (obj.distance > this.distance)
//            return 1;
//        else if (obj.distance == this.distance)
//            return 0;
//        else
//            return -1;

        return Double.compare(obj.distance, this.distance);
    }
}
