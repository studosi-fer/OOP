package t2;

import java.util.Arrays;

public class Bankar {

    public static void pohlepnoGrabljenje(){
        char[] array = new char[Integer.MAX_VALUE];

        Arrays.fill(array, '$');;

        System.out.println("Uspjeh");
    }

    public static void main(String[] args) {
        try
        {
            pohlepnoGrabljenje();
        }
        catch (Exception e) // Exception ne hvata OutOfMemoryError jer on spada u Error nadklasu
        {
            System.err.println("Ha! Uhvacen na djelu!" + e.getMessage());
        }
        catch (OutOfMemoryError e) // ovdje ga uhvati
        {
            System.err.println("Your PC ran out of memory!");
        }
        catch (Error e) // ovdje hvata svaku drugu Error podklasnu grešku
        {
            System.err.println("Semi-unknown error...");
        }
        catch (Throwable e) // ovime pokrivamo svaku grešku (bazna klasa)
        {
            System.err.println("Unknown error :(");
        }
    }
}
