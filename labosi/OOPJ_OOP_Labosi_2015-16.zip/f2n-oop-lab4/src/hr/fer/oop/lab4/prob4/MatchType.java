package hr.fer.oop.lab4.prob4;

/**
 * Enumeration {@MatchType} determines if the match type is competitive or
 * friendly.
 * 
 * @author dinomario10
 */
public enum MatchType {
	COMPETITIVE, FRIENDLY
}
