package hr.fer.oop.primjeri.p008;

public enum Sex {
	MALE, FEMALE;
}