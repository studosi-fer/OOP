package t3;

public class Main {
    public static void main(String[] args) {
        // Creating an array of plants
        Plant[] plants = new Plant[2];

        // A violet needs 2 liters of water
        Violet violet = new Violet(2);

        // A tomato needs 10 liters of water
        // Keep in mind - a Tomato is a Plant, and a Plant is a Growable
        Growable tomato = new Tomato(10);

        plants[0] = violet;
        // Be careful, not every Growable is a Plant - we just know this one is!
        // For example, mushrooms can be grown, but are not plants.
        plants[1] = (Plant) tomato;

        System.out.println("Gardener " + Plant.GARDENER + " is grooming the garden");

        for (Plant plant : plants) {
            // Plants can't be plucked immediately
            plant.pluck();

            // We spend some time watering our plants
            plant.water(1);
            plant.water(1);
            // Here we managed to water our Violet, but not our Tomato

            // We fertilize both plants
            plant.fertilize();

            // We succeed in plucking the Violet, but not our Tomato
            plant.pluck();
        }
    }
}
