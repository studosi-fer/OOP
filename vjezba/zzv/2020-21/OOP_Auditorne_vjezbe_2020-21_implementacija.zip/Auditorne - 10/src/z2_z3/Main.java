package z2_z3;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Predicate;

public class Main {
    public static void main(String[] args) {
//        Employee e = new Employee("Pero", 10000, LocalDate.of(2019, 12, 1));
//        System.out.println(e);
//
//        e.raiseSalary(20);
//        System.out.println(e);

        List<Employee> employees = new ArrayList<>();
        employees.addAll(EmployeeLoader.loadFromFile("employeesInfo.txt"));

        for (Employee employee : employees){
            System.out.println(employee);
        }

        System.out.println("\n===== 3. zadatak =====\n");

        System.out.println("Junior Employees:");
        printEmployees(employees, new JuniorEmployee());

        System.out.println("\nSenior Employees:");
        printEmployees(employees, new SeniorEmployee());

        System.out.println("\nSalary raise by 15%");
        for (Employee employee : employees){
            employee.raiseSalary(15);
        }

        System.out.println("\nNew Junior Employees:");
        printEmployees(employees, new Predicate<Employee>() {
            @Override
            public boolean test(Employee employee) {
                return employee.getSalary() < 80000;
            }
        });

        System.out.println("\nNew Senior Employees:");
        printEmployees(employees, (employee) -> employee.getSalary() >= 80000);

        theMostSimilarEmployees(employees, (employee1, employee2) -> (int) Math.abs(employee1.getHireDate().toEpochDay() - employee2.getHireDate().toEpochDay()));
    }

    public static void printEmployees(Iterable<Employee> it, Predicate<Employee> filter){
        for (Employee employee: it){
            if (filter.test(employee)){
                System.out.println(employee);
            }
        }
    }

    public static void theMostSimilarEmployees(Iterable<Employee> employees, BiFunction<Employee, Employee, Integer> similarityFunction){
        Employee similarA = null;
        Employee similarB = null;
        int similarityValue = Integer.MAX_VALUE;

        for (Employee employee1: employees){
            for (Employee employee2: employees){
                if (employee1 != employee2 && similarityFunction.apply(employee1, employee2) < similarityValue){
                    similarA = employee1;
                    similarB= employee2;
                    similarityValue = similarityFunction.apply(employee1, employee2);
                }
            }
        }

        System.out.format("\n2 most similar employees (days difference = %d):\n%s [%s] | %s [%s]",
                similarityValue,  similarA.getName(), similarA.getHireDate(), similarB.getName(), similarB.getHireDate());
    }

}
