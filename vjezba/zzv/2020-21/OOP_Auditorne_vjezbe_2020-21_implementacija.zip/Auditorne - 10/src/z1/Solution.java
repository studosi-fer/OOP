package z1;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

class Solution {
    public static List<List<String>> groupAnagrams(String[] input){
        List<String> sortedWords = new ArrayList<>();
        List<List<String>> groupedAnagrams = new ArrayList<>();

        for (String word : input) {
            String sortedWord = sortedWord(word);
            int index = sortedWords.indexOf(sortedWord);

            if (index == -1){
                List<String> wordList = new ArrayList<>();
                wordList.add(word);
                groupedAnagrams.add(wordList);

                sortedWords.add(sortedWord);
            } else {
                groupedAnagrams.get(index).add(word);
            }
        }

        return groupedAnagrams;
    }

    private static String sortedWord(String word) {
        Set<Character> sortedCharacters = new TreeSet<>();

        for (int i = 0; i < word.length(); i++) {
            sortedCharacters.add(word.charAt(i));
        }

        String sortedWord = "";
        for (Character c : sortedCharacters) {
            sortedWord += c;
        }

        return sortedWord;

//        StringBuilder sortedWord = new StringBuilder();
//        for (Character c : sortedCharacters) {
//            sortedWord.append(c);
//        }
//
//        return sortedWord.toString();
    }
}
