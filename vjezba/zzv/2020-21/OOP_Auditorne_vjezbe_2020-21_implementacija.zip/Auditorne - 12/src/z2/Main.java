package z2;

import z1.Loader;

import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Map<String, Map<String, Integer>> gradeMaps = Loader.loadData();
        
        System.out.println(getAverageCourseGrades(gradeMaps));
        System.out.println(getAverageStudentGrades(gradeMaps));
    }

    private static Map<String, Double> getAverageStudentGrades(Map<String, Map<String, Integer>> gradeMaps) {
        Map<String, List<Integer>> nameGradesMap = new HashMap<>();

        gradeMaps.values().stream().flatMap(nameGradeMap -> nameGradeMap.entrySet().stream()).
                forEach(nameGradePair -> nameGradesMap.merge(nameGradePair.getKey(),
                        new LinkedList<>(Arrays.asList(nameGradePair.getValue())),
                        (oldGradeList, passedGradeList) -> {
                    oldGradeList.addAll(passedGradeList);
                    return oldGradeList;
                }));

        return nameGradesMap.entrySet().stream().
                map(nameGradeList -> new AbstractMap.SimpleEntry<>(nameGradeList.getKey(),
                        nameGradeList.getValue().stream().mapToInt(Integer::intValue).average().getAsDouble())).
        collect(Collectors.toMap(AbstractMap.SimpleEntry::getKey, AbstractMap.SimpleEntry::getValue));

//        return gradeMaps.values().stream().flatMap(nameGradeMap -> nameGradeMap.entrySet().stream()).
//                collect(Collectors.groupingBy(Map.Entry::getKey, Collectors.averagingDouble(Map.Entry::getValue)));
    }

    private static Map<String, Double> getAverageCourseGrades(Map<String, Map<String, Integer>> gradeMaps) {
        return gradeMaps.entrySet().stream().
                map(courseNameGradeMap -> new AbstractMap.SimpleEntry<>(courseNameGradeMap.getKey(),
                        courseNameGradeMap.getValue().values().stream().
                                mapToInt(Integer::intValue).average().getAsDouble())).
                collect(Collectors.toMap(AbstractMap.SimpleEntry::getKey, AbstractMap.SimpleEntry::getValue));
    }
}
