package t2;

import t1.SimpleArrayList;

import java.util.Scanner;

public class Doodle {

    public static final String DOODLE_FORMAT = "|%-10s|%-10d|\n";
    public static final String DOODLE_HEADER = "|   ---    |Time      |\n";
    public static final String EOI = "END";

    private SimpleArrayList names = new SimpleArrayList();
    private SimpleArrayList times = new SimpleArrayList();

    void askTimes() {
        Scanner sc = new Scanner(System.in);

        String line;

        while (true){

            System.out.println("Plesae enter your name or \"END\" for finishing input.");
            line = sc.nextLine();

            if(line.equals(EOI)){
                break;
            }


            String name = line;
            int time;

            while (true){
                System.out.println(name + ", please enter time for meeting (0-23): ");
                line = sc.nextLine();
                time = Integer.parseInt(line);
                if (time >= 0 && time <= 23){
                    break;
                }
            }

            System.out.println("Name: " + name + " Time: " + time);
            names.add(name);
            times.add(Integer.valueOf(time));
        }


    }

    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();

        sb.append(DOODLE_HEADER);

        for (int i = 0; i < names.size(); i++) {
            sb.append(String.format(DOODLE_FORMAT, names.get(i), times.get(i)));
        }

        return sb.toString();
    }


}
