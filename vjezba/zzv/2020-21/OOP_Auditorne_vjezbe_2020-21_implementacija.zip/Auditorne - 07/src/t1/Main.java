package t1;

public class Main {
    public static void main(String[] args) {
        MyList<String> list = new MyList<>();
        list.add("A");
        list.add("B");
        list.add("C");
        // list.add(0);
        list.print();
        System.out.println("---");

        list.removeAt(1);
        System.out.println(" Element added at index " + list.add("D"));
        list.print();
        System.out.println("---");

        list.removeAt(0);
        list.print();
        System.out.println("---");

        list.removeAt(1);
        list.print();
        System.out.println("---");

        list.removeAt(17);
        list.print();
        System.out.println("---");

        list.removeAt(0);
        list.print();
        System.out.println("---");

        list.removeAt(0);
        list.print();
        System.out.println("---");

        list.add("E");
        list.print();
        System.out.println("---");


    }
}
