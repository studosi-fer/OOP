package z2.list;

class Score {
    private String name;
    private double distance;

    public Score(String name, double distance) {
        this.name = name;
        this.distance = distance;
    }

    public double getDistance() {
        return distance;
    }

    @Override
    public String toString() {
        return "name= " + name + ", distance= " + distance + "m";
    }
}
