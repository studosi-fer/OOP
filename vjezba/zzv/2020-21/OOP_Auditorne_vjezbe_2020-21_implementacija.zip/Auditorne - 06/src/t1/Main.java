package t1;

public class Main {
    public static void main(String[] args) {
        Prodavac.zabiljezi("12345.45,4,0.12");
        Prodavac.zabiljezi("a,2,2.3");
        Prodavac.zabiljezi("1,2");
        Prodavac.zabiljezi(null);
        Prodavac.zabiljezi(" 4, 0,1");
        Prodavac.zabiljezi(" 4, 0,4");
        Prodavac.zabiljezi("44, 3, 100");
        Prodavac.zabiljezi("102,12,3,4,5,6,7,8,9,0");
        Prodavac.zabiljezi(",,");
        Prodavac.zabiljezi("-7,2,-5");
    }

}