package t2;

class MyListElement<U> {
    private U content;
    private MyListElement<U> next;

    public MyListElement(U content) {
        this.content = content;
    }

    public MyListElement(U content, MyListElement<U> next) {
        this.content = content;
        this.next = next;
    }

    public U getContent() {
        return content;
    }

    public void setContent(U content) {
        this.content = content;
    }

    public MyListElement<U> getNext() {
        return next;
    }

    public void setNext(MyListElement<U> next) {
        this.next = next;
    }
}
