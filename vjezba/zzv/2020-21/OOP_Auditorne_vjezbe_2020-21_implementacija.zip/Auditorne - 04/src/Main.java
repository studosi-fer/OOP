public class Main {

    public static void main(String[] args) {
        Animal a1 = new Animal();
        a1.introduceYourself();

        Lion l1 = new Lion();
        Duck d1 = new Duck();
        l1.introduceYourself();
        d1.introduceYourself();

        System.out.println("\n===== Task 2 =====\n");

        Animal a2 = new Octopus();
        a2.introduceYourself();

        SeaAnimal b = new Octopus();
        b.introduceYourself();
        b.wayOfMovement();

        Fish c = new Fish();
        c.introduceYourself();
        c.wayOfMovement();

        System.out.println("\n===== Task 3 =====\n");

        l1.makeSound();
        d1.makeSound();
    }

}
