package t3;

public class Tomato extends Plant{

    public Tomato (int waterNeeded){
        super.waterNeeded = waterNeeded;
    }
}
