package z4.grades;

import java.util.*;

class Grades {
    private Map<String, List<Integer>> subjectGrades;

    public Grades() {
        this.subjectGrades = new HashMap<>();
    }

    public void addStudentGrade(String name, Integer... grades){

        List<Integer> values = subjectGrades.get(name);
        if (values == null){
            values = new ArrayList<>();
            subjectGrades.put(name, values);
        }
        values.addAll(Arrays.asList(grades));
    }

    public double getStudentAverage(String name){
        double gradeAverage = 0.;
        List<Integer> values = subjectGrades.get(name);
        for (Integer grade : values){
            gradeAverage += grade;
        }
        gradeAverage /= values.size();

        return gradeAverage;
    }

    public void printAverageGrades(){
        double gradeSum;

        double subjectSum = 0;
        int totalGradeNum = 0;

        for (String name : subjectGrades.keySet()){
            gradeSum = 0;

            for (Integer grade : subjectGrades.get(name)){
                gradeSum += grade;
            }

            System.out.println(name + ": " + gradeSum / subjectGrades.get(name).size());


            totalGradeNum += subjectGrades.get(name).size();
            subjectSum += gradeSum;
        }

        System.out.println("Subject average: " + subjectSum / totalGradeNum);
    }

}
