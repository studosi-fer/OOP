package t2;

public class Main {
    public static void main(String[] args) {
        Doodle doodle = new Doodle();
        doodle.askTimes();

        System.out.println(doodle);
    }
}
