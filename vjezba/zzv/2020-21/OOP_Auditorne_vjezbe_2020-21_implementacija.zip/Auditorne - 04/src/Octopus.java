public class Octopus extends SeaAnimal{

    public Octopus(){
        super(SeaSpecies.CEPHALOPOD);
    }

    public void wayOfMovement(){
        System.out.println("An octopussy moves by swimming and walking");
    }

}
