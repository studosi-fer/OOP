package t3;

class MyListElement <U> {
    private U content;
    private MyListElement<U> next;

    public MyListElement(U content) {
        this.content = content;
    }

    public U getContent() {
        return content;
    }

    public void setContent(U content) {
        this.content = content;
    }

    public MyListElement<U> getNext() {
        return next;
    }

    public void setNext(MyListElement<U> next) {
        this.next = next;
    }
}
