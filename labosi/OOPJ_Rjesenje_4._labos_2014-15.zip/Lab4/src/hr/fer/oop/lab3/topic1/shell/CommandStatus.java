package hr.fer.oop.lab3.topic1.shell;

/**
 * Used to decide whether to continue running the shell or to exit.
 * 
 * @author Filip
 *
 */
public enum CommandStatus {

	Continue, Exit;

}
