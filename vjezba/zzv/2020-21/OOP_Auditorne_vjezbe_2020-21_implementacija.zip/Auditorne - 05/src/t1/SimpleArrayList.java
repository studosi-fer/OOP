package t1;

public class SimpleArrayList {

    private Object elements[] = new Object[2];
    private int size = 0;

    public boolean add(Object o){
        if (elements.length == size){
            doubleArray();
        }
        elements[size++] = o;
        return true;
    }

    private void doubleArray() {
        Object newElements[] = new Object[elements.length * 2];
        for (int i = 0; i < size; i++) {
            newElements[i] = elements[i];
        }
        elements = newElements;
    }

    public int size(){
        return size;
    }

    public Object get(int index){
        return elements[index];
    }

    public int indexOf(Object o){
        for (int i = 0; i < elements.length; i++) {
            if (elements[i] == o){
                return i;
            }
        }
        return -1;
    }



}
