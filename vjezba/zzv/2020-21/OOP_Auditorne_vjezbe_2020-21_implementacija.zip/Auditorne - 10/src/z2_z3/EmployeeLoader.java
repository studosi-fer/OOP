package z2_z3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class EmployeeLoader {
    public static List<Employee> loadFromFile(String fileName){
        List<Employee> employees = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("employeesInfo.txt", StandardCharsets.UTF_8))){

            String line = reader.readLine();

            while (line != null){
                employees.add(readEmployee(line));
                line = reader.readLine();
            }

        } catch (IOException e) {
            System.err.println("Can not read data from file " + fileName);
            e.printStackTrace();
        }

        return employees;
    }

    private static Employee readEmployee(String line) throws IOException {
        String[] infoSplits = line.split(";");

        if (infoSplits.length < 5){
            throw new IOException("Can not read employee. Not enough elements in line: " + line);
        }

        String name = infoSplits[0];

        double salary;
        try {
            salary = Double.parseDouble(infoSplits[1]);
        } catch (NumberFormatException e){
            throw new IOException("Can not read salary in line: " + line, e);
        }

        int year;
        try {
            year = Integer.parseInt(infoSplits[2]);
        } catch (NumberFormatException e){
            throw new IOException("Can not read year in line: " + line, e);
        }

        int month;
        try {
            month = Integer.parseInt(infoSplits[3]);
        } catch (NumberFormatException e){
            throw new IOException("Can not read months in line: " + line, e);
        }

        int day;
        try {
            day = Integer.parseInt(infoSplits[4]);
        } catch (NumberFormatException e){
            throw new IOException("Can not read day in line: " + line, e);
        }

        try {
            return new Employee(name, salary, LocalDate.of(year, month, day));
        } catch (DateTimeException e){
            throw new IOException("Can not create hire date with line: " + line, e);
        }
    }
}
