package t3;

public class TeddyBearToy extends Toy{
    public TeddyBearToy(int size, String desc) {
        super(size, desc);
    }

    @Override
    public String toString(){
        return String.format("Teddy: %s", super.toString());
    }
}
