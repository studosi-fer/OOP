package t1;

public class Main {

    public static void main(String[] args) {
        SimpleArrayList list = new SimpleArrayList();

        print(list); // ništa
        list.add("prvi");
        list.add("drugi");
        list.add("treci");
        list.add("cetvrti");
        list.add("treci");
        print(list); // prvi

        System.out.println("indexOf(treći) = " + list.indexOf("treci"));
        System.out.println("indexOf(osmi) = " + list.indexOf("osmi"));
        System.out.println("indexOf(new treći) = " + list.indexOf(new String("treci")));
    }

    private static void print(SimpleArrayList list){
        System.out.print("Lista: ");
        for (int i = 0; i < list.size(); i++) {
            System.out.print(list.get(i));
            System.out.print(" ");
        }
        System.out.println();
        System.out.println("size: " + list.size());
    }
}
