package t3;

public class TooLittleSpace extends Exception{
    public TooLittleSpace (String message){
        super(message);
    }
}
