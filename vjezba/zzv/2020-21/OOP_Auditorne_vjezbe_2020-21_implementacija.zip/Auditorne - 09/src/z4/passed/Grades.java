package z4.passed;

import java.util.*;

class Grades {
    private Map<String, Map<String, Integer>> subjectGrades;

    public Grades() {
        this.subjectGrades = new HashMap<>();
    }

    public void add(String name, String subject, Integer grade){

        Map<String, Integer> subjectsMap = subjectGrades.get(name);

        if (subjectsMap == null){
            subjectsMap = new HashMap<String, Integer>();
            subjectGrades.put(name, subjectsMap);
        }
        subjectsMap.put(subject, grade);
    }

    public void printAverageSubjectGrade(String subjectName){
        double gradeSum = 0;
        int studentsPerSubject = 0;

        for (String name : subjectGrades.keySet()){

            if (subjectGrades.get(name).keySet().contains(subjectName)){
                gradeSum += subjectGrades.get(name).get(subjectName);
                studentsPerSubject++;
            }

            // druga verzija
//            for (String subjectValue : subjectGrades.get(name).keySet()){
//                if (subjectName == subjectValue){
//                    gradeSum += subjectGrades.get(name).get(subjectName);
//                    studentsPerSubject++;
//                    break;
//                }
//            }

        }

        System.out.println(subjectName +  " average: " + gradeSum / studentsPerSubject);
    }

}
